# 🕐 ClockTrack — Employee Time Tracker

A self-contained, locally hosted intranet app for tracking employee clock-ins and clock-outs. No server required — just open the HTML file in a browser on your local network.

Built with pure HTML, CSS, and JavaScript. All data is saved locally in your browser's storage and can be backed up and restored as a JSON file.

---

## ✨ Features

- **Clock In / Out** — Employees tap their ID tag or use the kiosk screen
- **Employee Management** — Add, edit, and remove employees with roles, hourly rates, and emoji avatars
- **Payroll Reports** — Generate hour summaries for any date range, per employee or across all staff
- **Adjustments** — Add or subtract hours manually with a reason (e.g. missed punch, extra shift)
- **Absences** — Log sick days, vacation, stat holidays, and more
- **Quick Links** — Pin frequently used URLs for your team
- **Backup & Restore** — Export all data to a JSON file and restore it anytime
- **Print Employee Tags** — Generate scannable ID tags for each employee

---

## 🚀 Getting Started

### 1. Open the file
Just open `ClockTrack.html` in any modern browser. No installation needed.

For shared access across your location, host it on a local machine and open it from other devices using the machine's local IP address (e.g. `http://192.168.1.10/ClockTrack.html`).

### 2. Customize your settings
Open `ClockTrack.html` in a text editor and find the **CONFIG** section near the top of the `<script>` tag:

```javascript
const CONFIG = {
  companyName: "Your Company Name",       // Shown in the header
  payrollEmail: "payroll@example.com",    // Used when emailing the payroll summary
  payrollContactName: "your payroll contact",  // Shown in reminders
  accentColor: "#c1090b",                 // Primary color (hex)
  payrollDueDay: 15,                      // Day of month payroll is due (0 = disable reminders)
};
```

Save the file after making your changes.

### 3. Add your employees
- Click the **Employees** tab
- Hit **Add Employee** and fill in their name, role, hourly rate, and assign them a tag ID
- Print their ID tag from the employee card

---

## 💾 Backing Up Your Data

Go to the **Settings** tab and click **Export Backup**. This downloads a `clocktrack-backup-*.json` file containing all employees, clock events, adjustments, and absences.

To restore, click **Import Backup** and select your JSON file.

> ⚠️ Data is stored in your browser's local storage. If you clear your browser data, you will lose everything unless you have a backup. **Export regularly.**

---

## 📧 Payroll Email

When you generate a payroll report, there's a button to email it directly to your payroll contact. This uses your device's default mail app (e.g. Outlook, Apple Mail) and pre-fills the recipient, subject, and body automatically using the `payrollEmail` and `payrollContactName` values from the CONFIG.

---

## 🛠 Requirements

- Any modern browser (Chrome, Firefox, Edge, Safari)
- No internet connection required after the initial load
- Google Fonts are loaded from the web — the app still works offline but will fall back to system fonts

---

## 📋 Notes

- This app uses `localStorage` — data is tied to the specific browser and device it was set up on
- For multi-device use, keep one machine as the "source of truth" and back up regularly
- The kiosk tab is designed for a touchscreen or shared terminal

---

*Built with ❤️ and Vibe Coded by BashCreates — [bashcreates.ca](https://bashcreates.ca)*
