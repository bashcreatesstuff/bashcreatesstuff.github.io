# Equipment Service Report Generator

A standalone, single-file HTML tool for generating professional equipment service reports as PDFs. No internet connection required after the first load. Runs entirely in the browser — no server, no account, no app needed.

---

## Quick Start

1. **Open** `Service_Report_Generator.html` in any modern browser (Chrome, Edge, Firefox, Safari).
2. **Set your branding** in the blue setup bar at the top.
3. **Fill in the report details** and add your equipment.
4. **Generate PDF** — done.

---

## Features

### ⚙️ Company Branding Setup (top bar)
Enter your details once and click **Apply**. They'll be saved automatically for next time.

| Field | What it does |
|---|---|
| **Company / Business Name** | Appears in the page header and on the PDF |
| **Tagline or department** | Subtitle shown under your company name |
| **Upload Logo** | Your logo appears in the header and on every PDF |

> Your branding is stored locally in your browser. It will still be there the next time you open the file on the same device.

---

### 📋 Report Details
Fill in per-visit information:

- **Client / Site Name** — the location or customer being serviced
- **Date of Service** — date picker
- **Technician Name** — who performed the work
**Report Notes** — optional field for general comments (shows on PDF)

---

### 🔧 Equipment List
Each row in the equipment list has three fields:

| Field | Description |
|---|---|
| **Equipment Name** | Treadmill, rower, cable machine, etc. |
| **Notes / Work Performed** | What was done, parts replaced, observations |
| **Status** | One of six condition codes (see below) |

**Status codes:**

| Status | Colour | Meaning |
|---|---|---|
| Good - No Repairs | Green | Equipment is in good working order, no action needed |
| Good - Serviced | Green | Equipment was serviced and is in good working order |
| Functional - Parts N/A | Orange | Functional but a needed part is unavailable |
| Functional - Needs Repairs | Orange | Working but repair is recommended |
| Out of Order - Decommission | Red | Should be removed from service permanently |
| Out of Order - Needs Repairs | Red | Down for repair — needs work before use |

**Tips:**
- Drag the ⠿ handle on the left to reorder rows.
- Rows expand automatically as you type notes.
- Click **+ Add Equipment Item** to add more rows.
- Click **×** to remove a row.

---

### 💾 Saved Reports
You can save named snapshots of a report to return to later.

1. Type a name in the **Save name** field (e.g. `Main Street Gym — June 2026`).
2. Click **Save Current**.
3. Your saved reports appear in the sidebar — click **Load** to restore one, **Delete** to remove it.

> Saves are stored in your browser's local storage. They persist across sessions on the same device/browser, but won't transfer to another device.

---

### 🖨️ PDF Output

Click **Generate PDF** (or **Preview Report** first).

The PDF includes:
- Your company name and logo
- Client name, date, technician, and notes
- Full equipment table with status badges
- Summary bar showing counts by status

The file is named `Service_Report_[ClientName].pdf` automatically.

---

### 📱 Mobile Use
The tool works on phones and tablets. After generating the PDF on mobile, tap the **share icon** to email it directly.

---

## No Data Leaves Your Device
Everything — your branding, your saves, your draft — is stored only in your browser's local storage. Nothing is sent anywhere.

---

## File Structure
This is a **single HTML file**. No installation, no dependencies to download, no build step. Just open it.

Dependencies are loaded from a CDN on first use:
- [jsPDF](https://github.com/parallax/jsPDF) — PDF generation
- [SortableJS](https://github.com/SortableJS/Sortable) — drag-to-reorder
- Google Fonts (Bebas Neue + DM Sans)

If you need it to work fully offline, download those libraries separately and update the `<script src>` and `@import` lines in the file.

---

## Customisation Tips

### Change the accent colour
Find this near the top of the file and change the hex value:
```css
:root {
  --accent: #1a4fa3;  /* ← change this to your brand colour */
}
```

### Add or remove status options
Find `STATUS_OPTIONS` in the script section and edit the array.

### Change the PDF filename format
Find this line near the bottom of `generatePDF()`:
```js
doc.save(`Service_Report_${safeName}.pdf`);
```

---

## Browser Compatibility
Works in all modern browsers. Chrome and Edge give the best PDF output experience.
