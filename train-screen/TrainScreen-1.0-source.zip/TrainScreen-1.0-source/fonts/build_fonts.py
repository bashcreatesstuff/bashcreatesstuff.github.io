import base64, io, re, sys
from fontTools.ttLib import TTFont
from fontTools.varLib import instancer
from fontTools import subset

html = open(sys.argv[1], encoding='utf-8').read()
chars = set(html) | set(chr(c) for c in range(0x20, 0x7f)) | set('｜…–—‘’“”°')
chars = {c for c in chars if ord(c) >= 0x20}
text = ''.join(sorted(chars))

# exactly the weights the original Google Fonts link asked for
SPEC = [('Noto Sans', 'NotoSans.ttf', [300,400,500,600,700]),
        ('Noto Sans JP', 'NotoSansJP.ttf', [300,400,500,700]),
        ('Noto Sans Mono', 'NotoSansMono.ttf', [500])]
css = []
total = 0
for fam, path, weights in SPEC:
    for w in weights:
        f = TTFont(path)
        loc = {'wght': w}
        if any(a.axisTag == 'wdth' for a in f['fvar'].axes): loc['wdth'] = 100
        f = instancer.instantiateVariableFont(f, loc, updateFontNames=False)
        opts = subset.Options(); opts.layout_features = ['*']; opts.name_IDs = ['*']; opts.notdef_outline = True
        opts.flavor = 'woff'; opts.hinting = True
        s = subset.Subsetter(opts); s.populate(text=text); s.subset(f)
        buf = io.BytesIO(); f.flavor = 'woff'; f.save(buf); data = buf.getvalue(); total += len(data)
        print(fam, w, len(data))
        css.append("@font-face{font-family:'%s';font-style:normal;font-weight:%d;font-display:block;src:url(data:font/woff;base64,%s) format('woff')}" % (fam, w, base64.b64encode(data).decode()))
print('total', total, 'chars', len(text))
open('fonts.css','w').write('\n'.join(css))
