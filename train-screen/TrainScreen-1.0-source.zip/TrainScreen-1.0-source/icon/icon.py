from PIL import Image, ImageDraw
import math
S = 1024
G, GD, GREY, RED, WHITE = (124,194,66,255), (69,167,43,255), (139,146,158,255), (200,24,32,255), (255,255,255,255)
im = Image.new('RGBA', (S, S), (0,0,0,0))
d = ImageDraw.Draw(im)
d.rounded_rectangle((40, 150, 984, 874), radius=90, fill=(24,26,29,255))
x0,y0,x1,y1 = 92, 202, 932, 822
hb = y0 + 220
sc = Image.new('RGBA', (S,S), (214,219,232,255)); sd = ImageDraw.Draw(sc)
B, C, T = (x0+620, y1+40), (x0+520, hb+120), (x0-40, hb+70)
def pt(t): u=1-t; return (u*u*B[0]+2*u*t*C[0]+t*t*T[0], u*u*B[1]+2*u*t*C[1]+t*t*T[1])
def tan(t): u=1-t; dx=2*u*(C[0]-B[0])+2*t*(T[0]-C[0]); dy=2*u*(C[1]-B[1])+2*t*(T[1]-C[1]); return math.atan2(dy,dx)
def stroke(t0,t1,w0,w1,col):
    N=400
    for i in range(N+1):
        t=t0+(t1-t0)*i/N; w=(w0+(w1-w0)*i/N)/2; x,y=pt(t); sd.ellipse((x-w,y-w,x+w,y+w),fill=col)
stroke(0.55,1.0,100,70,GREY)
stroke(0.0,0.57,150,100,GD)
for t,rr in ((0.40,28),(0.53,23),(0.70,13),(0.86,11)):
    x,y=pt(t); sd.ellipse((x-rr,y-rr,x+rr,y+rr),fill=WHITE)
x,y=pt(0.22); a=tan(0.22)
rot=lambda px,py:(x+px*math.cos(a)-py*math.sin(a), y+px*math.sin(a)+py*math.cos(a))
sd.polygon([rot(*p) for p in [(-62,-56),(22,-56),(70,0),(22,56),(-62,56)]], fill=RED, outline=WHITE, width=9)
sd.rectangle((0,0,S,hb), fill=(56,59,58,255))
sd.rectangle((x0+60, y0+34, x0+118, hb-34), fill=G)
sd.rounded_rectangle((x0+170, y0+58, x0+580, y0+118), radius=14, fill=(236,236,236,255))
sd.rounded_rectangle((x0+170, y0+140, x0+430, y0+180), radius=12, fill=(150,154,156,255))
mask = Image.new('L', (S,S), 0); ImageDraw.Draw(mask).rounded_rectangle((x0,y0,x1,y1), radius=44, fill=255)
im.paste(sc, (0,0), mask)
d = ImageDraw.Draw(im)
d.rectangle((452, 874, 572, 930), fill=(24,26,29,255))
d.rounded_rectangle((330, 920, 694, 970), radius=20, fill=(24,26,29,255))
im.save('icon-1024.png')
sizes = [16,20,24,32,40,48,64,128,256]
im.save('app.ico', sizes=[(s,s) for s in sizes])
def row(bg):
    st = Image.new('RGBA', (sum(sizes)+len(sizes)*10, 256), bg); x=0
    for s in sizes:
        t2 = im.resize((s,s), Image.LANCZOS); st.paste(t2,(x,256-s),t2); x+=s+10
    return st
a,b=row((240,240,240,255)),row((32,32,32,255))
o=Image.new('RGBA',(a.width,512)); o.paste(a,(0,0)); o.paste(b,(0,256)); o.save('icon-strip.png')
