//go:build windows

package main

import (
	_ "embed"
	"encoding/json"
	"net/url"
	"os"
	"path/filepath"
	"strconv"
	"unsafe"

	"golang.org/x/sys/windows"
)

//go:embed settings.html
var settingsHTML []byte

var (
	pEnableWindow          = user32.NewProc("EnableWindow")
	pSetForegroundWindow   = user32.NewProc("SetForegroundWindow")
	pGetDpiForSystem       = user32.NewProc("GetDpiForSystem")
	pDwmSetWindowAttribute = windows.NewLazySystemDLL("dwmapi.dll").NewProc("DwmSetWindowAttribute")
	pBringWindowToTop      = user32.NewProc("BringWindowToTop")
	pGetWindowRect         = user32.NewProc("GetWindowRect")
	pMonitorFromWindow     = user32.NewProc("MonitorFromWindow")
	pMonitorFromPoint      = user32.NewProc("MonitorFromPoint")
	pGetForegroundWindow   = user32.NewProc("GetForegroundWindow")
	pGetWindowThreadPID    = user32.NewProc("GetWindowThreadProcessId")
	pAttachThreadInput     = user32.NewProc("AttachThreadInput")
	pSetWindowPos          = user32.NewProc("SetWindowPos")
	pSetActiveWindow       = user32.NewProc("SetActiveWindow")
	pGetCurrentThreadId    = kernel32.NewProc("GetCurrentThreadId")
	configOwner            uintptr
	configTopmost          bool
)

// Windows only lets the app that's already in front hand focus to another window,
// so borrow the foreground window's input queue for a moment while we take over.
func bringToFront(hwnd uintptr) {
	fg, _, _ := pGetForegroundWindow.Call()
	cur, _, _ := pGetCurrentThreadId.Call()
	other, _, _ := pGetWindowThreadPID.Call(fg, 0)
	if other != 0 && other != cur {
		pAttachThreadInput.Call(cur, other, 1)
		defer pAttachThreadInput.Call(cur, other, 0)
	}
	pSetForegroundWindow.Call(hwnd)
	pBringWindowToTop.Call(hwnd)
	pSetActiveWindow.Call(hwnd)
}

// once the settings window is active it's in front anyway, so stop forcing it on top
func dropTopmost(hwnd uintptr) {
	if fg, _, _ := pGetForegroundWindow.Call(); configTopmost && fg == hwnd {
		configTopmost = false
		const hwndNoTopmost = ^uintptr(1)                                         // -2
		pSetWindowPos.Call(hwnd, hwndNoTopmost, 0, 0, 0, 0, 0x0001|0x0002|0x0010) // NOSIZE|NOMOVE|NOACTIVATE
	}
}

// centres the settings window over the Screen Saver dialog (or the primary screen),
// kept inside that monitor's work area
func placeOver(owner uintptr, w, h int32) (int32, int32) {
	mi := monitorInfo{Size: uint32(unsafe.Sizeof(monitorInfo{}))}
	var mon uintptr
	var cx, cy int32
	var r rect
	if owner != 0 {
		if ok, _, _ := pGetWindowRect.Call(owner, uintptr(unsafe.Pointer(&r))); ok != 0 {
			mon, _, _ = pMonitorFromWindow.Call(owner, 2) // nearest
			cx, cy = (r.Left+r.Right)/2, (r.Top+r.Bottom)/2
		}
	}
	if mon == 0 {
		mon, _, _ = pMonitorFromPoint.Call(0, 1) // primary
	}
	pGetMonitorInfoW.Call(mon, uintptr(unsafe.Pointer(&mi)))
	wa := mi.Work
	if cx == 0 && cy == 0 {
		cx, cy = (wa.Left+wa.Right)/2, (wa.Top+wa.Bottom)/2
	}
	x, y := cx-w/2, cy-h/2
	x = max(wa.Left, min(x, wa.Right-w))
	y = max(wa.Top, min(y, wa.Bottom-h))
	return x, y
}

type settings struct {
	Dim   int    `json:"dim"`   // percent darker, 0-80
	Clock string `json:"clock"` // "24" or "12"
}

func settingsPath() string { return filepath.Join(dataDir(), "settings.json") }

func loadSettings() settings {
	s := settings{Dim: 0, Clock: "24"}
	if b, err := os.ReadFile(settingsPath()); err == nil {
		json.Unmarshal(b, &s)
	}
	s.clean()
	return s
}

func (s *settings) clean() {
	if s.Dim < 0 {
		s.Dim = 0
	}
	if s.Dim > 80 {
		s.Dim = 80
	}
	if s.Clock != "12" {
		s.Clock = "24"
	}
}

func (s settings) query() url.Values {
	q := url.Values{}
	if s.Dim > 0 {
		q.Set("dim", strconv.Itoa(s.Dim))
	}
	if s.Clock == "12" {
		q.Set("clock", "12")
	}
	return q
}

// closes the program, giving the Screen Saver Settings window back its focus first
func quit() {
	if configOwner != 0 {
		pEnableWindow.Call(configOwner, 1)
		pSetForegroundWindow.Call(configOwner)
	}
	os.Exit(0)
}

func runConfig(owner uintptr) {
	dlog("config: owner=%x", owner)
	pagePath() // the preview inside the settings page uses it
	page := writeAsset("settings.html", settingsHTML)
	cls := registerClass()

	dpi := uintptr(96)
	if pGetDpiForSystem.Find() == nil {
		if d, _, _ := pGetDpiForSystem.Call(); d != 0 {
			dpi = d
		}
	}
	w, h := int32(600*dpi/96), int32(840*dpi/96)
	x, y := placeOver(owner, w, h)
	title, _ := windows.UTF16PtrFromString("Yamanote Line Train Screen Saver")
	const wsCaption, wsSysMenu = 0x00C00000, 0x00080000
	// starts always-on-top so it can never open hidden behind other windows;
	// wndProc drops that once the window has been activated
	configTopmost = true
	hwnd, _, _ := pCreateWindowExW.Call(wsExTopmost, uintptr(unsafe.Pointer(cls)), uintptr(unsafe.Pointer(title)),
		wsCaption|wsSysMenu|wsVisible|wsClipChildren,
		uintptr(x), uintptr(y), uintptr(w), uintptr(h), owner, 0, 0, 0)
	dlog("config: window %x at %d,%d size %dx%d (dpi %d)", hwnd, x, y, w, h, dpi)
	bringToFront(hwnd)
	dark := int32(1)
	pDwmSetWindowAttribute.Call(hwnd, 20, uintptr(unsafe.Pointer(&dark)), 4)
	if owner != 0 {
		configOwner = owner
		pEnableWindow.Call(owner, 0)
	}

	cur := loadSettings()
	dlog("config: embedding")
	v := newView(hwnd, fileURL(page, cur.query()), func(m string) {
		var in struct {
			Action string `json:"action"`
			settings
		}
		if json.Unmarshal([]byte(m), &in) != nil {
			return
		}
		if in.Action == "save" {
			s := in.settings
			s.clean()
			b, _ := json.MarshalIndent(s, "", "  ")
			os.WriteFile(settingsPath(), b, 0o644)
		}
		quit()
	})
	dlog("config: view ready=%v", v != nil)
	views[hwnd].Focus()
	loop()
}
