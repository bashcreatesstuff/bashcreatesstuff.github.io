//go:build windows && testhooks

// Test-only hooks, compiled in with -tags testhooks:
//   /autoexit:N  quit after N seconds
//   /debug:DIR   write log.txt and two screen captures into DIR
//   /q:dim=50&clock=12  override saved settings
//   /ptest       run the small preview inside a stand-in 480x300 window

package main

import (
	"fmt"
	"image"
	"image/png"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"
	"unsafe"

	"golang.org/x/sys/windows"
)

var (
	gdi32                   = windows.NewLazySystemDLL("gdi32.dll")
	pGetDC                  = user32.NewProc("GetDC")
	pReleaseDC              = user32.NewProc("ReleaseDC")
	pCreateCompatibleDC     = gdi32.NewProc("CreateCompatibleDC")
	pCreateCompatibleBitmap = gdi32.NewProc("CreateCompatibleBitmap")
	pSelectObject           = gdi32.NewProc("SelectObject")
	pBitBlt                 = gdi32.NewProc("BitBlt")
	pGetDIBits              = gdi32.NewProc("GetDIBits")
	pDeleteObject           = gdi32.NewProc("DeleteObject")
	pDeleteDC               = gdi32.NewProc("DeleteDC")
	logLines                []string
)

func dlog(f string, a ...any) {
	logLines = append(logLines, time.Now().Format("15:04:05.000 ")+fmt.Sprintf(f, a...))
}

func debugArg(name string) string {
	for _, a := range os.Args[1:] {
		if v, ok := strings.CutPrefix(a, "/"+name+":"); ok {
			return v
		}
	}
	return ""
}

// grabs the whole virtual desktop into a PNG (test builds only)
func captureScreen(path string) error {
	x, _, _ := pGetSystemMetrics.Call(76)
	y, _, _ := pGetSystemMetrics.Call(77)
	w, _, _ := pGetSystemMetrics.Call(78)
	h, _, _ := pGetSystemMetrics.Call(79)
	sdc, _, _ := pGetDC.Call(0)
	defer pReleaseDC.Call(0, sdc)
	mdc, _, _ := pCreateCompatibleDC.Call(sdc)
	defer pDeleteDC.Call(mdc)
	bmp, _, _ := pCreateCompatibleBitmap.Call(sdc, w, h)
	defer pDeleteObject.Call(bmp)
	pSelectObject.Call(mdc, bmp)
	pBitBlt.Call(mdc, 0, 0, w, h, sdc, uintptr(int32(x)), uintptr(int32(y)), 0x00CC0020|0x40000000)
	type bih struct {
		Size          uint32
		Width, Height int32
		Planes, Bits  uint16
		Compression   uint32
		SizeImage     uint32
		XP, YP        int32
		ClrUsed, Imp  uint32
	}
	hdr := bih{Size: 40, Width: int32(w), Height: -int32(h), Planes: 1, Bits: 32}
	buf := make([]byte, int(w)*int(h)*4)
	pGetDIBits.Call(mdc, bmp, 0, h, uintptr(unsafe.Pointer(&buf[0])), uintptr(unsafe.Pointer(&hdr)), 0)
	img := image.NewRGBA(image.Rect(0, 0, int(w), int(h)))
	for i := 0; i < len(buf); i += 4 {
		img.Pix[i], img.Pix[i+1], img.Pix[i+2], img.Pix[i+3] = buf[i+2], buf[i+1], buf[i], 255
	}
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	return png.Encode(f, img)
}

func startDebug() {
	if v := debugArg("autoexit"); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			go func() { time.Sleep(time.Duration(n) * time.Second); os.Exit(0) }()
		}
	}
	dir := debugArg("debug")
	if dir == "" {
		return
	}
	go func() {
		for i, at := range []int{6, 20} {
			time.Sleep(time.Duration(at-[]int{0, 6}[i]) * time.Second)
			err := captureScreen(fmt.Sprintf("%s\\shot%d.png", dir, i+1))
			dlog("capture %d: %v", i+1, err)
			os.WriteFile(dir+"\\log.txt", []byte(strings.Join(logLines, "\r\n")), 0o644)
		}
	}()
}

func testQuery(q url.Values) {
	if v := debugArg("q"); v != "" {
		if o, err := url.ParseQuery(v); err == nil {
			for k := range o {
				q.Set(k, o.Get(k))
			}
		}
	}
}

func testMode() bool {
	for _, a := range os.Args[1:] {
		if strings.EqualFold(a, "/ctest") {
			cls := registerClass()
			title, _ := windows.UTF16PtrFromString("Owner test")
			host, _, _ := pCreateWindowExW.Call(0, uintptr(unsafe.Pointer(cls)), uintptr(unsafe.Pointer(title)),
				0x00C00000|0x00080000|wsVisible, uintptr(^uint32(1500-1)), 200, 400, 300, 0, 0, 0, 0)
			runConfig(host)
			return true
		}
		if strings.EqualFold(a, "/ptest") {
			cls := registerClass()
			title, _ := windows.UTF16PtrFromString("Preview test")
			host, _, _ := pCreateWindowExW.Call(wsExTopmost, uintptr(unsafe.Pointer(cls)), uintptr(unsafe.Pointer(title)),
				0x00C00000|0x00080000|wsVisible, 200, 200, 480, 300, 0, 0, 0, 0)
			runPreview(host)
			return true
		}
	}
	return false
}
