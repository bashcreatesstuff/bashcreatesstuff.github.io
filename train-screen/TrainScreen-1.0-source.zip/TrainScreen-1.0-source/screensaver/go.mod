module trainscreen

go 1.21

require (
	github.com/jchv/go-webview2 v0.0.0
	golang.org/x/sys v0.30.0
)

require github.com/jchv/go-winloader v0.0.0 // indirect

replace github.com/jchv/go-webview2 => ../mods/go-webview2-master

replace github.com/jchv/go-winloader => ../mods/go-winloader-master

replace golang.org/x/sys => ../mods/sys-0.30.0
