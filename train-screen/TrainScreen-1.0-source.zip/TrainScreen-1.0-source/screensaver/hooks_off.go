//go:build windows && !testhooks

package main

import "net/url"

func startDebug()          {}
func dlog(string, ...any)  {}
func testQuery(url.Values) {}
func testMode() bool       { return false }
