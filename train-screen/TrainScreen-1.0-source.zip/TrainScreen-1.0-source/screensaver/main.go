//go:build windows

// Train Screen screensaver: one fullscreen WebView2 window per monitor,
// each showing train-screen.html as its own car. Exits on any input.
package main

import (
	_ "embed"
	"math"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unsafe"

	"github.com/jchv/go-webview2/pkg/edge"
	"golang.org/x/sys/windows"
)

//go:embed train-screen.html
var pageHTML []byte

var (
	user32   = windows.NewLazySystemDLL("user32.dll")
	kernel32 = windows.NewLazySystemDLL("kernel32.dll")

	pRegisterClassExW              = user32.NewProc("RegisterClassExW")
	pCreateWindowExW               = user32.NewProc("CreateWindowExW")
	pDefWindowProcW                = user32.NewProc("DefWindowProcW")
	pGetMessageW                   = user32.NewProc("GetMessageW")
	pTranslateMessage              = user32.NewProc("TranslateMessage")
	pDispatchMessageW              = user32.NewProc("DispatchMessageW")
	pPostQuitMessage               = user32.NewProc("PostQuitMessage")
	pEnumDisplayMonitors           = user32.NewProc("EnumDisplayMonitors")
	pGetMonitorInfoW               = user32.NewProc("GetMonitorInfoW")
	pGetCursorPos                  = user32.NewProc("GetCursorPos")
	pGetLastInputInfo              = user32.NewProc("GetLastInputInfo")
	pSetCursor                     = user32.NewProc("SetCursor")
	pShowCursor                    = user32.NewProc("ShowCursor")
	pGetClientRect                 = user32.NewProc("GetClientRect")
	pIsWindow                      = user32.NewProc("IsWindow")
	pMessageBoxW                   = user32.NewProc("MessageBoxW")
	pSetProcessDpiAwarenessContext = user32.NewProc("SetProcessDpiAwarenessContext")
	pGetStockObject                = windows.NewLazySystemDLL("gdi32.dll").NewProc("GetStockObject")
	pGetModuleHandleW              = kernel32.NewProc("GetModuleHandleW")
	pGetSystemMetrics              = user32.NewProc("GetSystemMetrics")
	pLoadIconW                     = user32.NewProc("LoadIconW")
)

const (
	wsPopup        = 0x80000000
	wsChild        = 0x40000000
	wsVisible      = 0x10000000
	wsClipChildren = 0x02000000
	wsExTopmost    = 0x00000008
	wsExToolWindow = 0x00000080
	wmDestroy      = 0x0002
	wmSize         = 0x0005
	wmSetCursor    = 0x0020
	wmClose        = 0x0010
	wmActivate     = 0x0006
	blackBrush     = 4
)

type rect struct{ Left, Top, Right, Bottom int32 }
type point struct{ X, Y int32 }
type msg struct {
	Hwnd    uintptr
	Message uint32
	WParam  uintptr
	LParam  uintptr
	Time    uint32
	Pt      point
	_       uint32
}
type wndClassEx struct {
	Size       uint32
	Style      uint32
	WndProc    uintptr
	ClsExtra   int32
	WndExtra   int32
	Instance   uintptr
	Icon       uintptr
	Cursor     uintptr
	Background uintptr
	MenuName   *uint16
	ClassName  *uint16
	IconSm     uintptr
}
type monitorInfo struct {
	Size    uint32
	Monitor rect
	Work    rect
	Flags   uint32
}
type lastInputInfo struct {
	Size uint32
	Time uint32
}

var (
	views      = map[uintptr]*edge.Chromium{}
	preview    bool
	fullscreen bool
)

func wndProc(hwnd, m, wp, lp uintptr) uintptr {
	switch m {
	case wmSetCursor:
		if fullscreen {
			pSetCursor.Call(0)
			return 1
		}
	case wmSize:
		if v := views[hwnd]; v != nil {
			v.Resize()
		}
	case wmActivate:
		if wp&0xffff != 0 {
			dropTopmost(hwnd)
		}
	case wmClose:
		quit()
	case wmDestroy:
		pPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := pDefWindowProcW.Call(hwnd, m, wp, lp)
	return r
}

func dataDir() string {
	base := os.Getenv("LOCALAPPDATA")
	if base == "" {
		base = os.TempDir()
	}
	d := filepath.Join(base, "TrainScreenSaver")
	os.MkdirAll(d, 0o755)
	return d
}

func writeAsset(name string, data []byte) string {
	p := filepath.Join(dataDir(), name)
	if old, err := os.ReadFile(p); err != nil || string(old) != string(data) {
		os.WriteFile(p, data, 0o644)
	}
	return p
}

func pagePath() string { return writeAsset("train-screen.html", pageHTML) }

func fileURL(p string, q url.Values) string {
	u := url.URL{Scheme: "file", Path: "/" + filepath.ToSlash(p), RawQuery: q.Encode()}
	return u.String()
}

func monitors() []rect {
	var out []rect
	cb := syscall.NewCallback(func(h, hdc, r, lp uintptr) uintptr {
		mi := monitorInfo{Size: uint32(unsafe.Sizeof(monitorInfo{}))}
		pGetMonitorInfoW.Call(h, uintptr(unsafe.Pointer(&mi)))
		out = append(out, mi.Monitor)
		return 1
	})
	pEnumDisplayMonitors.Call(0, 0, cb, 0)
	// cars run left to right, then top to bottom
	sort.Slice(out, func(i, j int) bool {
		if out[i].Left != out[j].Left {
			return out[i].Left < out[j].Left
		}
		return out[i].Top < out[j].Top
	})
	return out
}

func registerClass() *uint16 {
	name, _ := windows.UTF16PtrFromString("TrainScreenSaverWnd")
	inst, _, _ := pGetModuleHandleW.Call(0)
	brush, _, _ := pGetStockObject.Call(blackBrush)
	icon, _, _ := pLoadIconW.Call(inst, 1)
	wc := wndClassEx{
		Size:       uint32(unsafe.Sizeof(wndClassEx{})),
		WndProc:    syscall.NewCallback(wndProc),
		Instance:   inst,
		Icon:       icon,
		IconSm:     icon,
		Background: brush,
		ClassName:  name,
	}
	pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))
	return name
}

func newView(hwnd uintptr, target string, onMsg ...func(string)) *edge.Chromium {
	c := edge.NewChromium()
	if len(onMsg) > 0 {
		c.MessageCallback = onMsg[0]
	}
	c.DataPath = filepath.Join(dataDir(), "WebView2")
	views[hwnd] = c
	if !c.Embed(hwnd) {
		return nil
	}
	if c2 := c.GetController().GetICoreWebView2Controller2(); c2 != nil {
		c2.PutDefaultBackgroundColor(edge.COREWEBVIEW2_COLOR{A: 255})
	}
	if s, err := c.GetSettings(); err == nil {
		s.PutAreDefaultContextMenusEnabled(false)
		s.PutAreDevToolsEnabled(false)
		s.PutIsZoomControlEnabled(false)
		s.PutIsStatusBarEnabled(false)
	}
	c.Resize()
	c.Navigate(target)
	return c
}

// Quit on a key, click, wheel or a real mouse move (small jitter is ignored).
func watchInput() {
	time.Sleep(1500 * time.Millisecond)
	var start, prev point
	pGetCursorPos.Call(uintptr(unsafe.Pointer(&start)))
	prev = start
	li := lastInputInfo{Size: 8}
	pGetLastInputInfo.Call(uintptr(unsafe.Pointer(&li)))
	last := li.Time
	for {
		time.Sleep(50 * time.Millisecond)
		var p point
		pGetCursorPos.Call(uintptr(unsafe.Pointer(&p)))
		dx, dy := p.X-start.X, p.Y-start.Y
		if dx*dx+dy*dy > 12*12 {
			os.Exit(0)
		}
		pGetLastInputInfo.Call(uintptr(unsafe.Pointer(&li)))
		if li.Time != last {
			last = li.Time
			if p == prev { // input without the mouse moving: keyboard, button or wheel
				os.Exit(0)
			}
		}
		prev = p
	}
}

func loop() {
	var m msg
	for {
		r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			return
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
}

func runFull() {
	fullscreen = true
	cfg := loadSettings()
	cls := registerClass()
	page := pagePath()
	mons := monitors()
	if len(mons) == 0 {
		mons = []rect{{0, 0, 1920, 1080}}
	}
	pShowCursor.Call(0)
	dlog("monitors: %v page: %s", mons, page)
	car := 1
	for i, r := range mons {
		w, h := r.Right-r.Left, r.Bottom-r.Top
		// a wide monitor (21:9, 32:9...) gets two or three cars side by side instead of black bars
		n := 1
		if h > 0 {
			n = int(math.Round(float64(w) / float64(h) / (16.0 / 9.0)))
		}
		n = max(1, min(3, n))
		hwnd, _, _ := pCreateWindowExW.Call(wsExTopmost|wsExToolWindow, uintptr(unsafe.Pointer(cls)), 0,
			wsPopup|wsVisible|wsClipChildren,
			uintptr(r.Left), uintptr(r.Top), uintptr(w), uintptr(h), 0, 0, 0, 0)
		q := cfg.query()
		testQuery(q)
		q.Set("car", strconv.Itoa(car))
		q.Set("cars", strconv.Itoa(n))
		v := newView(hwnd, fileURL(page, q))
		dlog("window %d hwnd=%x view=%v url=%s", i, hwnd, v != nil, fileURL(page, q))
		car += n
	}
	go watchInput()
	loop()
}

func runPreview(parent uintptr) {
	preview = true
	cls := registerClass()
	var r rect
	pGetClientRect.Call(parent, uintptr(unsafe.Pointer(&r)))
	hwnd, _, _ := pCreateWindowExW.Call(0, uintptr(unsafe.Pointer(cls)), 0, wsChild|wsVisible|wsClipChildren,
		0, 0, uintptr(r.Right), uintptr(r.Bottom), parent, 0, 0, 0)
	go func() {
		for {
			time.Sleep(500 * time.Millisecond)
			if ok, _, _ := pIsWindow.Call(parent); ok == 0 {
				os.Exit(0)
			}
		}
	}()
	q := loadSettings().query()
	testQuery(q)
	q.Set("cars", "1")
	newView(hwnd, fileURL(pagePath(), q))
	loop()
}

func msgBox(text string) {
	t, _ := windows.UTF16PtrFromString(text)
	c, _ := windows.UTF16PtrFromString("Yamanote Line Train Screen")
	pMessageBoxW.Call(0, uintptr(unsafe.Pointer(t)), uintptr(unsafe.Pointer(c)), 0x40)
}

func main() {
	// sharp text on every monitor, whatever its scaling
	if pSetProcessDpiAwarenessContext.Find() == nil {
		pSetProcessDpiAwarenessContext.Call(^uintptr(3)) // PER_MONITOR_AWARE_V2 (-4)
	}
	// Windows passes /s, /p <hwnd>, /c or /c:<hwnd> (any case, - or /)
	mode, arg := "c", ""
	if len(os.Args) > 1 {
		a := strings.ToLower(strings.TrimLeft(os.Args[1], "/-"))
		if a != "" {
			mode = a[:1]
			if i := strings.IndexAny(a, ": "); i >= 0 {
				arg = a[i+1:]
			}
		}
		if arg == "" && len(os.Args) > 2 {
			arg = os.Args[2]
		}
	}
	startDebug()
	dlog("args: %q", os.Args)
	if testMode() {
		return
	}
	switch mode {
	case "s":
		runFull()
	case "p":
		h, err := strconv.ParseUint(strings.TrimSpace(arg), 10, 64)
		if err == nil && h != 0 {
			runPreview(uintptr(h))
		}
	default:
		h, _ := strconv.ParseUint(strings.TrimSpace(arg), 10, 64)
		runConfig(uintptr(h))
	}
}
