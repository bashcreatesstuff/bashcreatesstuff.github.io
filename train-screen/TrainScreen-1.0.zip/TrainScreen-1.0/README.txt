Yamanote Line Train Screen
Version 1.0.0
==========================

A Windows screensaver that recreates the passenger information screens on
Tokyo's Yamanote Line E235 trains. It runs on the real loop: all 30 stations
with real running times, transfers and exit names. The header switches between
kanji, kana and English, and the lower screen rotates through the line map,
platform and door guide, transfer list and train information.

Every monitor shows its own car (1, 2, 3 from left to right), and no two
monitors show the same screen at the same time. Wide monitors (21:9 and up)
get two or three cars side by side. All screens follow your PC's clock, so
they stay in sync with each other.


INSTALL
-------
1. Copy TrainScreen.scr somewhere it can stay. C:\Windows is a good choice
   (Windows will ask for admin approval). If you leave it in Downloads and
   later delete it, the screensaver stops working.
2. Right-click TrainScreen.scr and choose Install.
3. Windows opens Screen Saver Settings with "Yamanote Line Train Screen"
   selected. Pick a wait time and click OK.

The first time you run it, Windows may show "Windows protected your PC".
That appears for any small program that isn't code-signed. Click
"More info", then "Run anyway".


SETTINGS
--------
In Screen Saver Settings, click "Settings..." to open the options:

  Brightness   Dims every screen, from 100% down to 20%
  Clock        24-hour or 12-hour time

There's a live preview so you can see the change before you save.


REQUIREMENTS
------------
Windows 10 or 11 with the Microsoft Edge WebView2 Runtime. It comes with
Windows 11 and nearly every up-to-date Windows 10 PC. If the screen stays
black, install it from:
https://developer.microsoft.com/microsoft-edge/webview2/

No internet connection is needed. Everything, including the fonts, is built
into TrainScreen.scr.


USING IT WITH LIVELY WALLPAPER (OR A BROWSER)
---------------------------------------------
The "For Lively Wallpaper" folder has the same display as a single HTML file.
Drag it into Lively, and set it to span across all screens to get one car
per monitor. You can add options to the end of the address:

  ?dim=40       40% darker (0 to 80)
  ?clock=12     12-hour clock
  ?car=4        start numbering at car 4


UNINSTALL
---------
Choose a different screensaver (or None) in Screen Saver Settings and delete
TrainScreen.scr. Settings and a small cache are kept in
%LOCALAPPDATA%\TrainScreenSaver, which you can delete too.


CREDITS
-------
Vibe coded by Claude, with minor help and supervision by Bash Creates.
https://bashcreates.ca/train-screen

Fonts: Noto Sans, Noto Sans JP and Noto Sans Mono, used under the SIL Open
Font License 1.1. They're cut down to just the characters the screen uses.

Built with Go, go-webview2 (MIT) and go-winloader (ISC). License texts are
in the "licenses" folder.

This is an unofficial fan project and isn't affiliated with or endorsed by
JR East. Station names, line colours and transfer information are public
reference information. Running times are approximate.
